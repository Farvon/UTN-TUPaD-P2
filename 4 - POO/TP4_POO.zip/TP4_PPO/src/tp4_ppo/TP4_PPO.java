package tp4_ppo;

public class TP4_PPO {

    public static void main(String[] args) {

        Empleado e1 = new Empleado(1, "Facu", "Operador", 400);
        System.out.println(e1);
        Empleado.mostrarTotalEmpleados();
        Empleado e2 = new Empleado("Cris", "Tecnico");
        System.out.println(e2);
        Empleado.mostrarTotalEmpleados();
        Empleado e3 = new Empleado(2, "Raul", "Tecnico", 100);
        System.out.println(e3);
        Empleado.mostrarTotalEmpleados();
        Empleado e4 = new Empleado("Ana", "RRHH");
        System.out.println(e4);
        Empleado.mostrarTotalEmpleados();
        Empleado e5 = new Empleado(2, "Pablo", "Ingeniero", 200);
        System.out.println(e5);
        Empleado.mostrarTotalEmpleados();

        e2.actualizarSalario(0.10);
        e4.actualizarSalario(300);

        System.out.println("");
        System.out.println("Se actualizan salarios de Id = 2 e Id = 4 ---------");
        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);
        System.out.println(e4);
        System.out.println(e5);

    }

}
